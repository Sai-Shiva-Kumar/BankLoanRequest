package com.cg.banking.exceptions;

@SuppressWarnings("serial")
public class LoginException extends Exception{

	public LoginException() {
		super();
		
	}

	public LoginException(String arg0) {
		super(arg0);
	}

}
