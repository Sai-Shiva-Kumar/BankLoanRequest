package com.cg.banking.exceptions;

@SuppressWarnings("serial")
public class LoanProcessingException extends Exception {

	public LoanProcessingException() {
		super();
	}

	public LoanProcessingException(String message) {
		super(message);
		}
	

}

